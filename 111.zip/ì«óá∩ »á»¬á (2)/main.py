import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector
from tkinter import *
from threading import Timer

mysqldb = mysql.connector.connect(host="localhost",
                                  user="root",
                                  password="",
                                  database="autoriz")
class main:
    def __init__(self, master):

        self.master = master
        self.username = StringVar()
        self.password = StringVar()
        self.n_username = StringVar()
        self.n_password = StringVar()

        self.widgets()

    def login(self):
        c = mysqldb.cursor()

        find_user = ('select * from user where username = %s and password = %s')
        c.execute(find_user, [(self.username.get()), (self.password.get())])
        result = c.fetchall()
        if result:
            self.logf.pack_forget()

            t = Timer(0, self.master.destroy)
            t.start()
        else:
            messagebox.showerror('Внимание', 'Данный пользователь не найден!')

    def new_user(self):

        c = mysqldb.cursor()

        find_user = "select username from user where username = %s;"
        c.execute(find_user, [(self.n_username.get())])
        if c.fetchall():
            messagebox.showerror('yvedomlenie!', 'ima polzovatela zanato')
        else:
            insert="insert into user (username,password) values(%s, %s)"
            c.executemany(insert, [(self.n_username.get(), self.n_password.get())])
            messagebox.showinfo('ycpex', 'sozdan!')
            self.log()
        mysqldb.commit()

    def log(self):
        self.username.set('')
        self.password.set('')
        self.crf.pack_forget()
        self.head['text'] = 'aftoriz'
        self.logf.pack()

    def cr(self):
        self.username.set('')
        self.password.set('')
        self.logf.pack_forget()
        self.head['text'] = 'sozdat polzovatela'
        self.crf.pack()

    def widgets(self):
        self.head = Label(self.master, text='avtoriz', font=('', 35), pady=10)
        self.head.pack()
        self.logf = Frame(self.master, padx=10, pady=10)
        Label(self.logf, text='Login: ', font=('', 20), pady=5, padx=5).grid(sticky=W)
        Entry(self.logf, textvariable=self.username, bd=5, font=('',15)).grid(row=0, column=1)
        Label(self.logf, text='Password: ', font=('', 20), pady=5, padx=5).grid(sticky=W)
        Entry(self.logf, textvariable=self.password, bd=5, font=('', 15), show='*').grid(row=1, column=1)
        Button(self.logf, text=' Enter', bd=3, font=('', 15), padx=5, pady=5, command=self.login).grid()
        Button(self.logf, text=' New', bd=3, font=('', 15), padx=5, pady=5, command=self.cr).grid(row=2,
                                                                                                column=1)
        self.logf.pack()

        self.crf = Frame(self.master,padx=10, pady=10)
        Label(self.crf, text='Login: ', font=('', 20), pady=5, padx=5).grid(sticky=W)
        Entry(self.crf, textvariable=self.n_username, bd=5, font=('', 15)).grid(row=0, column=1)
        Label(self.crf, text='parol: ', font=('', 20), pady=5, padx=5).grid(sticky=W)
        Entry(self.crf, textvariable=self.n_password, bd=5, font=('', 15), show='*').grid(row=1, column=1)
        Button(self.crf, text=' sozdat', bd=3, font=('', 15), padx=5, pady=5, command=self.new_user).grid()
        Button(self.crf, text=' nazad', bd=3, font=('', 15), padx=5, pady=5, command=self.log).grid(row=2,
                                                                                                    column=1)


if __name__ == '__main__':

    roott = Tk()
    roott.title('avto')
    main(roott)
    roott.mainloop()

def GetValue(event):
    e1.delete(0, END)
    e2.delete(0, END)
    e3.delete(0, END)
    e4.delete(0, END)
    row_id = listBox.selection()[0]
    select = listBox.set(row_id)
    e1.insert(0, select['id'])
    e2.insert(0, select['title'])
    e3.insert(0, select['price'])
    e4.insert(0, select['punkt'])

def Add():
    sellnurik_id = e1.get()
    sellnurik_title = e2.get()
    sellnurik_price = e3.get()
    sellnurik_punkt = e4.get()

    mysqldb = mysql.connector.connect(host="localhost",
                                      user="root",
                                      password="",
                                      database="sellnurik")
    mycursor = mysqldb.cursor()

    try:
        sql = "INSERT INTO shop (id,title,price,punkt) VALUES (%s, %s, %s, %s)"
        val = (sellnurik_id, sellnurik_title, sellnurik_price, sellnurik_punkt)
        mycursor.execute(sql, val)
        mysqldb.commit()
        lastid = mycursor.lastrowid
        messagebox.showinfo("information", "Employee inserted successfully...")
        e1.delete(0, END)
        e2.delete(0, END)
        e3.delete(0, END)
        e4.delete(0, END)
        e1.focus_set()
    except Exception as e:
        print(e)
        mysqldb.rollback()
        mysqldb.close()

def update():
    sellnurik_id = e1.get()
    sellnurik_title = e2.get()
    sellnurik_price = e3.get()
    sellnurik_punkt = e4.get()
    mysqldb = mysql.connector.connect(host="localhost",
                                      user="root",
                                      password="",
                                      database="sellnurik")
    mycursor = mysqldb.cursor()

    try:
        sql = "Update shop set title= %s,price= %s,punkt= %s where id= %s"
        val = (sellnurik_id, sellnurik_title, sellnurik_price, sellnurik_punkt)
        mycursor.execute(sql, val)
        mysqldb.commit()
        lastid = mycursor.lastrowid
        messagebox.showinfo("information", "Record Updateddddd successfuly...")

        e1.delete(0, END)
        e2.delete(0, END)
        e3.delete(0, END)
        e4.delete(0, END)
        e1.focus_set()

    except Exception as e:

        print(e)
        mysqldb.rollback()
        mysqldb.close()

def delete():
    client_id = e1.get()

    mysqldb = mysql.connector.connect(host="localhost",
                                      user="root",
                                      password="",
                                      database="sellnurik")
    mycursor = mysqldb.cursor()

    try:
        sql = "delete from shop where id = %s"
        val = (client_id,)
        mycursor.execute(sql, val)
        mysqldb.commit()
        lastid = mycursor.lastrowid
        messagebox.showinfo("information", "Record Deleteeeee successfully...")

        e1.delete(0, END)
        e2.delete(0, END)
        e3.delete(0, END)
        e4.delete(0, END)
        e1.focus_set()

    except Exception as e:

        print(e)
        mysqldb.rollback()
        mysqldb.close()

def show():
    mysqldb = mysql.connector.connect(host="localhost",
                                      user="root",
                                      password="",
                                      database="sellnurik")
    mycursor = mysqldb.cursor()
    mycursor.execute("SELECT id, title, price, punkt FROM shop")
    records = mycursor.fetchall()
    print(records)

    for i, (id, title, price, punkt) in enumerate(records, start=1):
        listBox.insert("", "end", values=(id, title, price, punkt))
        mysqldb.close()

root = Tk()
root.geometry("800x500")
global e1
global e2
global e3
global e4
global e5

tk.Label(root, text="Заказы", fg="black", font=(None, 30)).place(x=300, y=5)

tk.Label(root, text="ID").place(x=10, y=10)
Label(root, text="title").place(x=10, y=40)
Label(root, text="price").place(x=10, y=70)
Label(root, text="punkt").place(x=10, y=100)

e1 = Entry(root)
e1.place(x=140, y=10)

e2 = Entry(root)
e2.place(x=140, y=40)

e3 = Entry(root)
e3.place(x=140, y=80)

e4 = Entry(root)
e4.place(x=140, y=100)


Button(root, text="Add", command=Add, height=3, width=13).place(x=30, y=130)
Button(root, text="update", command=update, height=3, width=13).place(x=140, y=130)
Button(root, text="Delete", command=delete, height=3, width=13).place(x=250, y=130)

cols = ('id', 'title', 'price', 'punkt')
listBox = ttk.Treeview(root, columns=cols, show='headings')

for col in cols:
    listBox.heading(col, text=col)
    listBox.grid(row=1, column=0, columnspan=2)
    listBox.place(x=10, y=200)

show()
listBox.bind('<Double-Button-1>', GetValue)

root.mainloop()